package com.beginner.variables;

public class MyFirstJavaApp {

    public static void main(String[] args) {
        int numberOfFollowers = 195;
    }
}
