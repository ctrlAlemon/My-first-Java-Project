package com.beginner.yourfirstjavacode;

public class MyFirstJavaApp {

    public  static void main(String[] args) {

        System.out.println("May the force be with you!");
    }
}
