public class PracticeVariables {

    // lesson 25 practice, coding with variables
    public static void main(String[] args) {

        short  totalHourPlayed = 1800;
        byte   numberOfLegends = 14;
        byte   numberOfAbilityForEachLegend = 3;

        byte   currentSeason = 6;
        byte   seasonPassLevels = 110;
        byte   currentPassLevel = 28;
        byte   remainingDaysBeforeSeasonEnds = 69; //today is 02/september/2020

        byte   totalLegendaryitems = 125;
        byte   totalLegendaryItemsOwned = 55;

        byte   heirloomAvaible = 5;
        byte   heirloomOwned =0;

        byte   allGameMode = 23;
        byte   currentlyPlayableGameMode = 5;

        byte   totalRanks = 7;
        byte   subRankOfEachRank = 4;
        int    currentRankedPoints = 5610;
        byte   pointsNeededForBronze = 0;
        short  pointsNeededForSilver = 1200;
        short  pointsNeededForGold = 2800;
        short  pointsNeededForPlatinum = 4800;
        short  pointsNeededForDiamond = 7200;
        short  pointsNeededForMasterAndPredator = 10000;
        short playerThatCanJoinPredator = 500;

        boolean amIPlatinum3 = true;

        System.out.println("Apex Legends");
        System.out.println("Time spent playing the game: " +totalHourPlayed + "hr");
        System.out.println("Total Legends in the game: " +numberOfLegends);
        System.out.println("Exclusive ability for each legend: " +numberOfAbilityForEachLegend);
        System.out.println("Current season" + currentSeason + " Boosted ");
        System.out.println("Max BattlePassLevel: " +seasonPassLevels );
        System.out.println("Current season pass level: " +currentPassLevel);
        System.out.println("Remaining days before this season ends: " +remainingDaysBeforeSeasonEnds);
        System.out.println("Number of legendary items : " + totalLegendaryitems );
        System.out.println("Number of legendary items owned: " +totalLegendaryItemsOwned );
        System.out.println("Total number of heirloom avaible at the moment: " +heirloomAvaible );
        System.out.println("Total heirloom owned: " +heirloomOwned + ":(");
        System.out.println("Number of all game mode of Apex legends: " +allGameMode );
        System.out.println("Currently playable gamemode: " +currentlyPlayableGameMode );
        System.out.println("Total Ranks in Apex Legends: " +totalRanks );
        System.out.println("Number of sub-rank per each rank: " +subRankOfEachRank );
        System.out.println("Current Ranked Point scored: " +currentRankedPoints );
        System.out.println("Points needed to achieve Bronze rank: " +pointsNeededForBronze );
        System.out.println("Points needed to achieve Silver rank: " +pointsNeededForSilver );
        System.out.println("Points needed to achieve Gold rank: " +pointsNeededForGold );
        System.out.println("Points needed to achieve Platinum rank: " +pointsNeededForPlatinum );
        System.out.println("Points needed to achieve Diamond rank: " +pointsNeededForDiamond );
        System.out.println("Points needed to achieve Master/Predator rank: " +pointsNeededForMasterAndPredator );
        System.out.println("Number of player allowed in the Predator rank: " +playerThatCanJoinPredator );
        System.out.println("my current rank is platinum 3: " +amIPlatinum3 );
        
    }
}